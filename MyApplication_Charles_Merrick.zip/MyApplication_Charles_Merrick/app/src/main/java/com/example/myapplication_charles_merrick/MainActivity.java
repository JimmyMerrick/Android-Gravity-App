package com.example.myapplication_charles_merrick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private TextView greetings;
    private Button sayHelloButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        greetings = findViewById(R.id.textGreeting);
        sayHelloButton = findViewById(R.id.SayHello);

        sayHelloButton.setEnabled(false);



    }

    @Override
    protected void onPause() {
        super.onPause();

        onResume();
    }

    @Override
    protected void onResume() {
        super.onResume();

        String userNameText = nameText.getText().toString();

        if (userNameText.isEmpty()) {
            greetings.setText("You must enter a name");
        }

        else {
            sayHelloButton.setEnabled(true);


        }


    }

    public void SayHello(View view) {

        String properGreeting;

        String userNameText = nameText.getText().toString();
        properGreeting = "Greetings " + userNameText;

        if (userNameText.isEmpty()) {
            greetings.setText("You must enter a name");
        }

        else {
            greetings.setText(properGreeting);
        }

    }

}